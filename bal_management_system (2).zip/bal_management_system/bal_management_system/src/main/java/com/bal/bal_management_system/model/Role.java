package com.bal.bal_management_system.model;

public enum Role {
    USER,
    ADMIN
    // Add other roles as necessary
}

